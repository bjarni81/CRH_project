# CRH Analysis

## Project description
This project is an analysis of Clinical Resource Hub (CRH) encounters in the VA
 
